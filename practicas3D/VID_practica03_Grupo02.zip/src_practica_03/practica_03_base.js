/*
* 
* Practica_02_base.js
* Videojuegos (30262) - Curso 2019-2020
* 
* Parte adaptada de: Alex Clarke, 2016, y Ed Angel, 2015.
* 
*/

// Eje X (izquierda)
// Eje Y (delante)
// Eje Z (arriba)

// Variable to store the WebGL rendering context
var gl;

//----------------------------------------------------------------------------
// OTHER DATA 
//----------------------------------------------------------------------------

var model = new mat4();   		// create a model matrix and set it to the identity matrix
var view = new mat4();   		// create a view matrix and set it to the identity matrix
var projection = new mat4();	// create a projection matrix and set it to the identity matrix

var eye, target, up;			// for view matrix

const gravity = 9.8;
const vmax = 3;
const fuerzaMovimiento = 5;  // Cuanta fuerza aplicamos
const masaEsfera = 1.0;        // Asumimos masa de 1 kg
let controlForces = [0, 0, 0]; // Almacena la fuerza aplicada

// Detectar teclas presionadas
window.addEventListener("keydown", (event) => {
    switch (event.key) {
        case "ArrowUp":    
			controlForces[0] = -fuerzaMovimiento;
			controlForces[1] = -fuerzaMovimiento; break;  // ↑ Mueve en Y-  y X-

        case "ArrowDown": 
			controlForces[0] = fuerzaMovimiento;
			controlForces[1] = fuerzaMovimiento; break;  // ↑ Mueve en Y+  y X+

        case "ArrowLeft":
			controlForces[0] = fuerzaMovimiento;
			controlForces[1] = -fuerzaMovimiento; break;  // ↑ Mueve en Y-  y X+

        case "ArrowRight":
			controlForces[0] = -fuerzaMovimiento;
			controlForces[1] = +fuerzaMovimiento; break;  // ↑ Mueve en Y+  y X-
    }
	console.log("keydown:", event.key, "controlForces:", controlForces);
});

// Detectar cuando se suelta la tecla (detener la fuerza)
window.addEventListener("keyup", (event) => {
    switch (event.key) {
        case "ArrowUp":
        case "ArrowDown":
        case "ArrowLeft":
        case "ArrowRight":
			controlForces[0] = 0; 
			controlForces[1] = 0;
			break;
    }

	console.log("keyup:", event.key, "controlForces:", controlForces);
});


var planeProgramInfo = {
	program: {},
	uniformLocations: {},
	attribLocations: {},
};

var sphereProgramInfo = {
	program: {},
	uniformLocations: {},
	attribLocations: {},
};

var numObjects = 20;

// Crea un número aleatorio entero entre 'min' y 'max'
function numAleatorioEntero(min, max) {
	return Math.floor(Math.random() * (max - min + 1) + min); // +1 para incluir 'n' en el rango
};

function posicionAleatoria(){
	let rand = numAleatorioEntero(1, limitePosicion);
	let signo = numAleatorioEntero(0, 1);
	if(signo == 1){
		rand = -rand;
	}
	return rand;
}


function rainbowSphereColor(value) {
    if (value < 0 || value > 1) {
        throw new Error("El valor debe estar entre 0 y 1.");
    }

    let hue = value * 360; // El valor ahora se escala entre 0 y 360
    let saturation = 1.0; // Máxima saturación para colores vivos
    let lightness = 0.5;  // Luminosidad media

    return hslToRgb(hue, saturation, lightness);
}


function rainbowPlaneColor(value) {
    if (value < 0 || value > 1) {
        throw new Error("El valor debe estar entre 0 y 1.");
    }

    let hue = value * 360; // El valor ahora se escala entre 0 y 360
    let saturation = 0.75; // Máxima saturación para colores vivos
    let lightness = 0.35;  // Luminosidad media

    return hslToRgb(hue, saturation, lightness);
}


// Función para convertir HSL a RGB
function hslToRgb(h, s, l) {
    let c = (1 - Math.abs(2 * l - 1)) * s;
    let x = c * (1 - Math.abs((h / 60) % 2 - 1));
    let m = l - c / 2;
    let r, g, b;

    if (h < 60) { r = c; g = x; b = 0; } 
    else if (h < 120) { r = x; g = c; b = 0; } 
    else if (h < 180) { r = 0; g = c; b = x; } 
    else if (h < 240) { r = 0; g = x; b = c; } 
    else if (h < 300) { r = x; g = 0; b = c; } 
    else { r = c; g = 0; b = x; }

    return [
        (r + m),
        (g + m),
        (b + m)
    ];
}

// Devuelve un array con los colores del cubo
function colorEsfera(color){
	let colorRGB = rainbowSphereColor(color);
	colorRGB = [colorRGB[0], colorRGB[1], colorRGB[2], 1.0];

	return colorRGB;
};

// Devuelve un array con los colores del cubo
function colorPlano(color){
	let colorRGB = rainbowPlaneColor(color);
	colorRGB = [colorRGB[0], colorRGB[1], colorRGB[2], 1.0];

	return colorRGB;
};


s = 10; // Size del plano

var planes = [
    // Suelo
    {
        position: [0.0, 0.0, 0.0],
        size: s,
        normal: [0.0, 0.0, 1.0],  // Normal hacia arriba (Z+)
    },
];


var spheres = []
for (let i = 0; i < numObjects; i++) {
	
    let object = {
        position: [0.0, 0.0, 0.0],
		rotation: [0.0, 0.0, 0.0],
		velocity: [0.0, 0.0, 0.0],
        angularVelocity: [0.0, 0.0, 0.0],
		radius: 1.5,
    };

    spheres.push(object);
}

var objectsToDraw = []


for (let i = 0; i < planes.length; i++) {
	colorAux = colorPlano((1/planes.length)*i);

	let object = {
        programInfo: planeProgramInfo,
        pointsArray: pointsPlane,
        uniforms: {
            u_color: colorAux,
            u_model: new mat4(),
        },
        primType: "triangles",
    };

	objectsToDraw.push(object);
}



for (let i = 0; i < numObjects; i++) {
	colorAux=[1.0, 1.0, 1.0, 1.0];
	if (i > 0){
		colorAux = colorEsfera((1/numObjects)*i);
	}
    let object = {
        programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
            u_color: colorAux,
			u_model: spheres[i].position,
		},
		primType: "triangles",
    };

	objectsToDraw.push(object);
}


//----------------------------------------------------------------------------
// Initialization function
//----------------------------------------------------------------------------

window.onload = function init() {
	// Set up a WebGL Rendering Context in an HTML5 Canvas
	var canvas = document.getElementById("gl-canvas");
	gl = WebGLUtils.setupWebGL(canvas);
	if (!gl) {
		alert("WebGL isn't available");
	}

	//  Configure WebGL
	gl.clearColor(0.0, 0.0, 0.0, 1.0);
	gl.enable(gl.DEPTH_TEST);
	gl.disable(gl.CULL_FACE);

	setPrimitive(objectsToDraw);

	// Set up a WebGL program for the plane
	// Load shaders and initialize attribute buffers
	planeProgramInfo.program = initShaders(gl, "plane-vertex-shader", "plane-fragment-shader");
	  
	// Save the attribute and uniform locations
	planeProgramInfo.uniformLocations.model = gl.getUniformLocation(planeProgramInfo.program, "model");
	planeProgramInfo.uniformLocations.view = gl.getUniformLocation(planeProgramInfo.program, "view");
	planeProgramInfo.uniformLocations.projection = gl.getUniformLocation(planeProgramInfo.program, "projection");
	planeProgramInfo.uniformLocations.baseColor = gl.getUniformLocation(planeProgramInfo.program, "baseColor");
	planeProgramInfo.attribLocations.vPosition = gl.getAttribLocation(planeProgramInfo.program, "vPosition");

	// Set up a WebGL program for spheres
	// Load shaders and initialize attribute buffers
	sphereProgramInfo.program = initShaders(gl, "sphere-vertex-shader", "sphere-fragment-shader");
	  
	// Save the attribute and uniform locations
	sphereProgramInfo.uniformLocations.model = gl.getUniformLocation(sphereProgramInfo.program, "model");
	sphereProgramInfo.uniformLocations.view = gl.getUniformLocation(sphereProgramInfo.program, "view");
	sphereProgramInfo.uniformLocations.projection = gl.getUniformLocation(sphereProgramInfo.program, "projection");
	sphereProgramInfo.uniformLocations.baseColor = gl.getUniformLocation(sphereProgramInfo.program, "baseColor");
	sphereProgramInfo.attribLocations.vPosition = gl.getAttribLocation(sphereProgramInfo.program, "vPosition");

	// Set up viewport 
	gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);

	// Set initial positions
	spheres.forEach(function(sphere, index) {
		if(index !== 0){ // Saltamos la blanca
			sphere.position = [5*(2*Math.random() - 1), 5*(2*Math.random() - 1), (5*(4*Math.random() - 1))+5];
		}
	});

	spheres[0].position = [0.0, 0.0, spheres[0].radius/2];
	
	// Actualiza los modelos de los planos
	planes.forEach(function(plane, index) {
		// Comienza la transformación con la traslación
		let transform = mat4();

		transform = mult(transform, translate(plane.position[0], plane.position[1], plane.position[2]));
		transform = mult(transform, scale(plane.size, plane.size, 1));  // Ajusta la escala en X, Y y Z

		// Actualiza el modelo del plano
		objectsToDraw[index].uniforms.u_model = transform;
	});


	lastTick = Date.now();
	requestAnimFrame(tick);
};

//----------------------------------------------------------------------------
// Tick Event Function
//----------------------------------------------------------------------------

var lastTick;

function tick(nowish) {
	var now = Date.now();

    var dt = now - lastTick;
	dt = Math.min(dt, 16*4);
    lastTick = now;

	update(dt)
	render(dt)

	window.requestAnimationFrame(tick)
}

//----------------------------------------------------------------------------
// Update Event Function
//----------------------------------------------------------------------------

// Función para detectar colisiones entre dos esferas
function detectarColisionEsferas(sphere1, sphere2) {
    // Calculamos la distancia entre los centros de las esferas
    let dx = sphere2.position[0] - sphere1.position[0];
    let dy = sphere2.position[1] - sphere1.position[1];
    let dz = sphere2.position[2] - sphere1.position[2];

    // Distancia entre los centros de las esferas
    let distancia = Math.sqrt(dx * dx + dy * dy + dz * dz);

    // Sumamos los radios de las dos esferas
    let sumaRadios = (sphere1.radius + sphere2.radius)/2;

    // Si la distancia es menor que la suma de los radios, hay colisión
    return distancia < sumaRadios;
}

// Función para separar las esferas después de una colisión
function separarEsferas(sphere1, sphere2,i) {
    let dx = sphere2.position[0] - sphere1.position[0];
    let dy = sphere2.position[1] - sphere1.position[1];
    let dz = sphere2.position[2] - sphere1.position[2];

    // Calculamos la distancia entre las esferas
    let distancia = Math.sqrt(dx * dx + dy * dy + dz * dz);

    // Sumamos los radios de las dos esferas
    let sumaRadios = (sphere1.radius + sphere2.radius)/2;

    // Si están colisionando, movemos las esferas para separarlas
    if (distancia < sumaRadios) {
        let diferencia = sumaRadios - distancia;  // Cuánto se superponen las esferas

        let normal = [dx / distancia, dy / distancia, dz / distancia];
		if(i!==0){
        	sphere1.position[2] -= normal[2] * diferencia / 2;
		}
		sphere1.position[0] -= normal[0] * diferencia / 2;
        sphere1.position[1] -= normal[1] * diferencia / 2;
        sphere2.position[0] += normal[0] * diferencia / 2;
        sphere2.position[1] += normal[1] * diferencia / 2;
        sphere2.position[2] += normal[2] * diferencia / 2;
    }
}

// Función para manejar las colisiones entre todas las esferas
function checkSphereCollisions() {
    for (let i = 0; i < spheres.length; i++) {
        for (let j = i + 1; j < spheres.length; j++) {
            if (detectarColisionEsferas(spheres[i], spheres[j])) {

                separarEsferas(spheres[i], spheres[j],i);

                // Después de separarlas, invertimos las velocidades en la dirección de la colisión
                let dx = spheres[j].position[0] - spheres[i].position[0];
                let dy = spheres[j].position[1] - spheres[i].position[1];
                let dz = spheres[j].position[2] - spheres[i].position[2];
                let distancia = Math.sqrt(dx * dx + dy * dy + dz * dz);

                // Normalizamos la dirección de la colisión
                let normal = [dx / distancia, dy / distancia, dz / distancia];

                // Invertimos las velocidades en la dirección de la colisión
                let v1 = spheres[i].velocity[0] * normal[0] + spheres[i].velocity[1] * normal[1] + spheres[i].velocity[2] * normal[2];
                let v2 = spheres[j].velocity[0] * normal[0] + spheres[j].velocity[1] * normal[1] + spheres[j].velocity[2] * normal[2];

                // Intercambiamos las velocidades en la dirección de la colisión
                spheres[i].velocity[0] -= 2 * v1 * normal[0];
                spheres[i].velocity[1] -= 2 * v1 * normal[1];
                spheres[i].velocity[2] -= 2 * v1 * normal[2];
				
                spheres[j].velocity[0] -= 2 * v2 * normal[0];
                spheres[j].velocity[1] -= 2 * v2 * normal[1];
                spheres[j].velocity[2] -= 2 * v2 * normal[2];
            }
        }
    }
}


function update(dt) {	
	index = planes.length;

	// Update state
	spheres.forEach(function(sphere, i) {

		// // Update graphical representation
		let transform = scale(sphere.radius, sphere.radius, sphere.radius);

        // Si la esfera está en el suelo, aplicamos rotación
        if (sphere.position[2] <= sphere.radius + 0.01) {
            let velocidadLineal = Math.sqrt(
                sphere.velocity[0] * sphere.velocity[0] +
                sphere.velocity[1] * sphere.velocity[1] +
                sphere.velocity[2] * sphere.velocity[2]
            );
            
            
            if (velocidadLineal > 0.1){
                let direction = Math.atan2(sphere.velocity[1], sphere.velocity[0]);

                // Normal al movimiento en X-Y (eje de rotación)
                let axisX = -Math.sin(direction);  // Eje X perpendicular
                let axisY = Math.cos(direction);   // Eje Y perpendicular

                // Calcular velocidad angular (θ = v / (2πr))
                let angularSpeed = velocidadLineal / (2 * Math.PI * sphere.radius);
                
                // Asignar velocidad angular en el eje correcto
                sphere.angularVelocity = [axisX * angularSpeed, axisY * angularSpeed, 0];
                
                sphere.rotation[0] += sphere.angularVelocity[0] * dt;
                sphere.rotation[1] += sphere.angularVelocity[1] * dt;
                sphere.rotation[2] += sphere.angularVelocity[2] * dt;
                
                if(i === 0) console.log(sphere.velocity)
            }
        }
        
        let ejeX = vec3(1.0, 0.0, 0.0);
		transform = mult(rotate(sphere.rotation[0], ejeX), transform);
		let ejeY = vec3(0.0, 1.0, 0.0);
		transform = mult(rotate(sphere.rotation[1], ejeY), transform);
        
		let ejeZ = vec3(0.0, 0.0, 1.0);
		transform = mult(rotate(sphere.rotation[2], ejeZ), transform);

		// Actualizamos la posición de la esfera
		if(i!==0){
			
            let plane = planes[0]; // Suelo
            let planeCenter = plane.position;
            let planeSize = plane.size;
            let distanceX = Math.abs(sphere.position[0]+ sphere.velocity[0]*dt/1000 - planeCenter[0]);
            let distanceY = Math.abs(sphere.position[1]+ sphere.velocity[1]*dt/1000 - planeCenter[1]);
			sphere.position[0] += sphere.velocity[0]*dt/1000;
			sphere.position[1] += sphere.velocity[1]*dt/1000;
			sphere.position[2] += sphere.velocity[2]*dt/1000; 
			
            // Aplicamos gravedad
            sphere.velocity[2] -= gravity * dt/1000;
			
            // Colisión esfera-suelo
			let sphereToPlane = Array.from(subtract(sphere.position, planes[0].position));

            if (distanceX <= planeSize && distanceY <= planeSize ) {
				// Distancia de la esfera al plano				
				let d = (sphereToPlane[0] * planes[0].normal[0]) +
						(sphereToPlane[1] * planes[0].normal[1]) +
						(sphereToPlane[2] * planes[0].normal[2]);
				
				if (d <= (sphere.radius + 0.0001)){ // ponemos un umbral para que deje de botar si pierde mucha energia
					
					sphere.velocity[2] = -sphere.velocity[2]*0.5;
					sphere.position[2] += (sphere.radius - d) + 0.0001;
                    
                    console.log(planeCenter)
				}
            }

			
		}
		else{ 
            // Aplicamos el control del usuario a la esfera blanca
            let acceleration = [
                controlForces[0] / masaEsfera,
                controlForces[1] / masaEsfera,
                0
            ];

            // Actualizamos velocidad según la aceleración
            sphere.velocity[0] += acceleration[0] * dt / 1000;
            sphere.velocity[1] += acceleration[1] * dt / 1000;

            // Limitamos la velocidad
            sphere.velocity[0] = Math.max(-vmax, Math.min(vmax, sphere.velocity[0]));
            sphere.velocity[1] = Math.max(-vmax, Math.min(vmax, sphere.velocity[1]));

            // Actualizamos su posición según la velocidad
            sphere.position[0] += sphere.velocity[0] * dt / 1000;
            sphere.position[1] += sphere.velocity[1] * dt / 1000;
            
            // Factores de frenado
			if (controlForces[0] === 0) {
                sphere.velocity[0] *= 0.9;
                if (Math.abs(sphere.velocity[0]) < 0.01) sphere.velocity[0] = 0;
            }
            if (controlForces[1] === 0) {
                sphere.velocity[1] *= 0.9;
                if (Math.abs(sphere.velocity[1]) < 0.01) sphere.velocity[1] = 0;
            }
            if (controlForces[2] === 0) {
                sphere.velocity[2] *= 0.9;
                if (Math.abs(sphere.velocity[2]) < 0.01) sphere.velocity[2] = 0;
            }

			// Esfera se sale del plano
            let plane = planes[0];
            let planeCenter = plane.position;
            let planeSize = plane.size;

            // Distancia esfera-plano
            let distanceX = Math.abs(sphere.position[0] - planeCenter[0]);
            let distanceY = Math.abs(sphere.position[1] - planeCenter[1]);
            let distanceZ = Math.abs(sphere.position[2] - planeCenter[2]);

            // Si se sale del plano, reseteamos
            if (distanceX > planeSize || distanceY > planeSize || distanceZ > planeSize) {
                // Reset sphere position to the origin
                sphere.position = [0.0, 0.0, spheres[0].radius/2.0];
                sphere.velocity = [0.0, 0.0, 0.0];
				controlForces[0] = 0;
				controlForces[1] = 0;
            }
		}
        
        
		transform = mult(translate(sphere.position[0], sphere.position[1], sphere.position[2]), transform);
		
		objectsToDraw[index].uniforms.u_model = transform;
		index += 1;

	});

    // Chequeamos las colisiones a posteriori
    checkSphereCollisions(spheres);
}

//----------------------------------------------------------------------------
// Rendering Event Function
//----------------------------------------------------------------------------

function render(dt) {
	// Clear the buffer and draw everything
	gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);

	objectsToDraw.forEach(function(object) {
		gl.useProgram(object.programInfo.program);

		// Setup buffers and attributes
		setBuffersAndAttributes(object.programInfo, object);

		// Set the uniforms
		setUniforms(object.programInfo, object.uniforms);

		// Draw
		gl.drawArrays(object.primitive, 0, object.pointsArray.length);
	});
}

//----------------------------------------------------------------------------
// Utils functions
//----------------------------------------------------------------------------

function setPrimitive(objectsToDraw) {	
	objectsToDraw.forEach(function(object) {
		switch(object.primType) {
		  case "lines":
			object.primitive = gl.LINES;
			break;
		  case "line_strip":
			object.primitive = gl.LINE_STRIP;
			break;
		  case "triangles":
			object.primitive = gl.TRIANGLES;
			break;
		  default:
			object.primitive = gl.TRIANGLES;
		}
	});	
}	

function setUniforms(pInfo, uniforms) {
    var canvas = document.getElementById("gl-canvas");

    // Set up camera
    // Projection matrix
    projection = perspective( 45.0, canvas.width/canvas.height, 0.1, 100.0 );
    gl.uniformMatrix4fv( pInfo.uniformLocations.projection, gl.FALSE, projection ); // copy projection to uniform value in shader
    
    // View matrix (dynamic cam)
    eye = vec3(spheres[0].position[0] + 10.0, spheres[0].position[1] + 10.0, spheres[0].position[2] + 10.0); // Camera follows the white sphere
    target = vec3(spheres[0].position[0], spheres[0].position[1], spheres[0].position[2]); // Camera looks at the white sphere
    up = vec3(0.0, 0.0, 1.0);
    view = lookAt(eye, target, up);
    
    gl.uniformMatrix4fv(pInfo.uniformLocations.view, gl.FALSE, view); // copy view to uniform value in shader

    // Copy uniform model values to corresponding values in shaders
    if (pInfo.uniformLocations.baseColor != null) {
        gl.uniform4f(pInfo.uniformLocations.baseColor, uniforms.u_color[0], uniforms.u_color[1], uniforms.u_color[2], uniforms.u_color[3]);
    }
    gl.uniformMatrix4fv(pInfo.uniformLocations.model, gl.FALSE, uniforms.u_model);
}

function setBuffersAndAttributes(pInfo, object) {
	// Load the data into GPU data buffers
	// Vertices
	var vertexBuffer = gl.createBuffer();
	gl.bindBuffer( gl.ARRAY_BUFFER, vertexBuffer );
	gl.bufferData( gl.ARRAY_BUFFER,  flatten(object.pointsArray), gl.STATIC_DRAW );
	gl.vertexAttribPointer( pInfo.attribLocations.vPosition, 4, gl.FLOAT, gl.FALSE, 0, 0 );
	gl.enableVertexAttribArray( pInfo.attribLocations.vPosition );
}
